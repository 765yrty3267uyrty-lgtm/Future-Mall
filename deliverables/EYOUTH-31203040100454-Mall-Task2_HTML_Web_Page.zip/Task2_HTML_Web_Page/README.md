# Task 2 - HTML Web Page

Future Mall main website (HTML5/CSS3/vanilla JS) plus the Digital Awareness
cybersecurity microsite. No frameworks - pure semantic HTML, custom properties,
CSS Grid/Flexbox, and inline SVG.

## Contents

- `website/` - main site (index.html, style.css, script.js, assets/)
- `digital_awareness/` - cybersecurity microsite (6 pages + posters)
- `shared/` - design tokens shared by both sites (constants.css/.js)

## Pages

| File | Description |
|------|-------------|
| `index.html` | Main site: hero, about, modules, digital awareness, brand, contact |
| `digital_awareness/index.html` | Cybersecurity home |
| `digital_awareness/threats.html` | Threat library (8 categories) |
| `digital_awareness/password.html` | Password strength checker + generator |
| `digital_awareness/quiz.html` | 15-question phishing quiz |
| `digital_awareness/posters.html` | 6 downloadable safety posters |

## Features

- Responsive (320px - 1440px+) with dark mode
- Accessibility: skip links, ARIA labels, image alt text
- Shared design tokens via `shared/constants.css` and `shared/constants.js`
- Google Fonts: Space Grotesk / Inter / JetBrains Mono

## Run locally

```bash
cd website
npx serve .
```
Open `http://localhost:3000` (main site) or
`http://localhost:3000/digital_awareness/`.

Part of the Future Mall capstone - HTML Web Page.
