# Task 1 - Python, Data & AI

Three console applications plus a desktop GUI, sharing one design system.

## Contents

- `cashier_program.py` - shop simulator: cart, tiered discounts, tax, receipts
- `visitors_analysis.py` - weekly visitor statistics (median, range, trends) + CSV/JSON export
- `product_classifier.py` - price / weight / stock classification with JSON persistence
- `attendance_system/` - Tkinter + SQLite desktop app (employee/supervisor/admin roles)
- `shared/constants.py` - brand & business constants shared by every module
- `tests/` - pytest suites for all modules
- `requirements.txt` - packages needed for tests

## Run

```bash
python cashier_program.py
python visitors_analysis.py
python product_classifier.py

# attendance desktop app
cd attendance_system
python -m pip install -r requirements.txt   # (tkinter ships with Python)
python main.py

# tests (from this folder)
python -m pip install -r requirements.txt
python -m pytest tests/ -v
```

## Design

Every module imports `shared/constants.py` (colors, tax rate, discount tiers,
classifier thresholds) so behaviour and branding stay consistent across the
project and match the web + branding modules.

Part of the Future Mall capstone - Python, Data & AI.
